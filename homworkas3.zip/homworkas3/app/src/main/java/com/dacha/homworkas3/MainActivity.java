package com.dacha.homworkas3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    public void calc(){
        if (textView.getText().toString().equals("0"))
            textView.setText(textView.setText());
        else {textView.append(textView.setText());}
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView.findViewById(R.id.text_view);
    }

    public void numberclick(View view) {
        switch (view.getId()){
            case R.id.btn_one:
                calc(textView.setText("1"););
                break;
            case R.id.btn_two:
                calc();
                break;
            case R.id.btn_three:
                calc();
                break;
            case R.id.clear:
                textView.setText("0");
        }
    }
}